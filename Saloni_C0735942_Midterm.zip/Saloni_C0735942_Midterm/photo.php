<?php
   $files = glob("photos/*.*");
   for ($i=0; $i<count($files); $i++)
    {
      $image = $files[$i];
      $supported_file = array('png');


         if (($_POST["userName"=="hungrytoronto" && "password"=="imsohungry"]) ) {
           Header("Location: food.html");
         }
         else if(($_POST["userName"=="jimmychin" && "password"=="camera915"])){
           Header("Location: climbing.html");
         }
       $ext = strtolower(pathinfo($image, PATHINFO_EXTENSION));
       if (in_array($ext, $supported_file)) {
          echo basename($image)."<br />"; // show only image name if you want to show full path then use this code // echo $image."<br />";
           //echo '<img src="'.$image .'" alt="Random image" />'."<br /><br />";
          } else {
              continue;
          }
        }
     ?>
