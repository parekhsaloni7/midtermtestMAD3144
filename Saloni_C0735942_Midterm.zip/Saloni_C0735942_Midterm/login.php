<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    print_r($_POST);
    //Array ( [customerName] => [emailAddress] => )
    if (empty($_POST["userName"]) ) {
      echo "Please enter your name";
    }
    else {
      echo "Got the name!";
    }
  }

  if (($_POST["userName"=="hungrytoronto" && "password"=="imsohungry"]) ) {
    Header("Location: food.html");
  }
  else if(($_POST["userName"=="jimmychin" && "password"=="camera915"])){
    Header("Location: climbing.html");
  }

  else{

  }


  if ($_SERVER["REQUEST_METHOD"] == "POST") {
      print_r($_POST);
      //Array ( [customerName] => [emailAddress] => )
      if (empty($_POST["userName"]) ) {
        echo "Please enter your name";
      }
      else {
        echo "Got the name!";
      }
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        print_r($_POST);
        //Array ( [customerName] => [emailAddress] => )
        if (empty($_POST["password"]) ) {
          echo "Please enter the password";
        }
        else {
          echo "Got the name!";
        }
      }

?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
      <link href="style.css" rel="stylesheet" type="text/css" />
    <link href="https://fonts.googleapis.com/css?family=Indie+Flower|Overpass+Mono" rel="stylesheet">

<script>
    var passwordPairs = {
      "hungrytoronto": "imsohungry",
      "jimmychin": "camera915"
    }

    function check(form) {
      if (passwordPairs[form.userid.value] === form.pswrd.value) && ($_POST["userName"=="hungrytoronto" && "password"=="imsohungry"])
      {
        window.open('climbing.html');
        alert("success");
        return false;
      }
      else if (passwordPairs[form.userid.value] === form.pswrd.value) && ($_POST["userName"=="jimmychin" && "password"=="camera915"])
      {
        window.open('food.html');
        alert("success");
        return false;
      }
      </script>
    }
    <title>Single Page Form</title>

  </head>
  <body text align="center">
    <div id="wrapper">
    <div class="main-content">
      <div class="header">
        <img src="https://i.imgur.com/zqpwkLQ.png" />
      </div>
      <div class="l-part">
        <input type="text" placeholder="Username" class="input-1" name = "userName" id="userName" required/>
        <div class="overlap-text">
          <input type="password" placeholder="Password" class="input-2" name = "password" id = "password"required/>
          </div>
        <input type="button" value="Log in" class="btn" action="food.html"/>
      </div>
    </div>

  </body>
</html>
